---
title: Phone landscape
layout: icon
categories:
  - Devices
tags:
  - mobile
  - telephone
---
