---
title: Credit card
layout: icon
categories:
  - Real world
tags:
  - debit
  - card
  - payment
---
