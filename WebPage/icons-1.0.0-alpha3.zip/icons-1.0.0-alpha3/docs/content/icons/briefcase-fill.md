---
title: Briefcase fill
layout: icon
categories:
  - Real world
tags:
  - business
---
