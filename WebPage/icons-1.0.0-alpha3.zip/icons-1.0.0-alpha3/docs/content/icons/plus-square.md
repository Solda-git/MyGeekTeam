---
title: Plus square
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - add
  - new
---
