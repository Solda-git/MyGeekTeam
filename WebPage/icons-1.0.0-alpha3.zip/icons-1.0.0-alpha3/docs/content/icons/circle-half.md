---
title: Circle half fill
layout: icon
categories:
  - Shapes
tags:
  - shape
---
