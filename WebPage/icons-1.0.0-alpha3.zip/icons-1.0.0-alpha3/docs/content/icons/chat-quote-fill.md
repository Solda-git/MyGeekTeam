---
title: Chat quote fill
layout: icon
categories:
  - Communications
tags:
  - chat bubble
  - text
  - message
  - quote
---
