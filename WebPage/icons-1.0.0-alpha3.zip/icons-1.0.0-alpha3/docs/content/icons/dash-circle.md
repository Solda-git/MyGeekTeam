---
title: Dash circle
layout: icon
categories:
  - UI and keyboard
tags:
  - minus
---
