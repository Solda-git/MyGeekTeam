---
title: Egg fill
layout: icon
categories:
  - Real world
tags:
  - food
---
