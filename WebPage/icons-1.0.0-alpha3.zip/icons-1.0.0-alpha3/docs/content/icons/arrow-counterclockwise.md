---
title: Arrow counterclockwise
layout: icon
categories:
  - Arrows
tags:
  - arrow
---
