---
title: File check
layout: icon
categories:
  - Files and folders
tags:
  - doc
  - document
  - check
  - verified
---
