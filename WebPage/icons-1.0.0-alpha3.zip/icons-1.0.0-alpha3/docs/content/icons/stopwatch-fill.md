---
title: Stopwatch fill
layout: icon
categories:
  - Devices
tags:
  - time
  - timer
---
