---
title: Battery
layout: icon
categories:
  - Devices
tags:
  - power
  - charge
---
