---
title: Star
layout: icon
categories:
  - Shapes
tags:
  - shape
  - like
  - favorite
---
