---
title: Caret down
layout: icon
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
