---
title: List OL
layout: icon
categories:
  - Typography
tags:
  - text
  - type
  - justify
  - alignment
  - ordered-list
  - numbered-list
  - numbered
---
