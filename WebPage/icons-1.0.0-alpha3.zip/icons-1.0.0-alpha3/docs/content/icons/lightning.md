---
title: Lightning
layout: icon
categories:
  - Misc
tags:
  - weather
  - storm
  - thunder
  - bolt
---
