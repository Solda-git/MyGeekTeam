---
title: Octagon half
layout: icon
categories:
  - Shapes
tags:
  - shape
  - polygon
---
