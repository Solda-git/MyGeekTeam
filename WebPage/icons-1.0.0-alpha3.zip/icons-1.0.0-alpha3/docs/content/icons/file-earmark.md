---
title: File earmark
layout: icon
categories:
  - Files and folders
tags:
  - doc
  - document
---
