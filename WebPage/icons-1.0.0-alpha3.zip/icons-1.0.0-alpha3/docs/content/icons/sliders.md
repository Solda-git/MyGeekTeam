---
title: Sliders
layout: icon
categories:
  - Graphics
tags:
  - equalizer
  - settings
  - preferences
  - dials
---
