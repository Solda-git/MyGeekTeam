---
title: Star half fill
layout: icon
categories:
  - Shapes
tags:
  - shape
  - like
  - favorite
---
