---
title: Sun
layout: icon
categories:
  - Real world
tags:
  - solar
  - weather
---
