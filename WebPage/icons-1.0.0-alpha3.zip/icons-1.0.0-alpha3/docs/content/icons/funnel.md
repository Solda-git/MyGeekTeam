---
title: Funnel
layout: icon
categories:
  - Real world
tags:
  - sort
  - filter
---
