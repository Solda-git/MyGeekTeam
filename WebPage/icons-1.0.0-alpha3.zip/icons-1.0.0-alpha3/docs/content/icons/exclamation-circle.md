---
title: Alert circle
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
