---
title: Heart
layout: icon
categories:
  - Shapes
tags:
  - love
  - favorite
---
