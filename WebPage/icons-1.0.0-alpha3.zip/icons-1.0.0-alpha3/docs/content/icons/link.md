---
title: Link
layout: icon
categories:
  - UI and keyboard
tags:
  - anchor
  - hyperlink
  - href
---
