---
title: Backspace reverse fill
layout: icon
categories:
  - UI and keyboard
tags:
  - key
---
