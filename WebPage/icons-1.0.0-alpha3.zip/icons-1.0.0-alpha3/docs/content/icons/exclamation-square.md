---
title: Alert square
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
