---
title: Mic mute fill
layout: icon
categories:
  - Media
tags:
  - audio
  - video
  - av
  - sound
  - input
  - microphone
---
