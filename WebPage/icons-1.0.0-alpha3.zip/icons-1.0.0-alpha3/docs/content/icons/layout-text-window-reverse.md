---
title: Layout text window reverse
layout: icon
categories:
  - Layout
tags:
  - layout
  - columns
---
