---
title: File earmark code
layout: icon
categories:
  - Files and folders
tags:
  - doc
  - document
  - code
  - development
---
