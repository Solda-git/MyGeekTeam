---
title: Droplet
layout: icon
categories:
  - Graphics
tags:
  - water-drop
  - paint
  - ink
  - liquid
---
