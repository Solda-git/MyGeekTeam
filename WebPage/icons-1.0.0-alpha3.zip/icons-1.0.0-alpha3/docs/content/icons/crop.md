---
title: Crop
layout: icon
categories:
  - Graphics
tags:
  - crop
---
