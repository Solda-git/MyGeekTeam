---
title: Caret left fill
layout: icon
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
