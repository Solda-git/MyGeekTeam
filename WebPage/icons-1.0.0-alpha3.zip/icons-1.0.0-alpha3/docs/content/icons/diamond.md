---
title: Diamond
layout: icon
categories:
  - Shapes
tags:
  - shape
---
