---
title: Caret left
layout: icon
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
