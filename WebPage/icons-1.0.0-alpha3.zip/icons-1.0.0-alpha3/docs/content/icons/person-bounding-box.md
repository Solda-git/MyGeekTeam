---
title: Person bounding box
layout: icon
categories:
  - People
tags:
  - human
  - individual
  - avatar
  - crop
---
