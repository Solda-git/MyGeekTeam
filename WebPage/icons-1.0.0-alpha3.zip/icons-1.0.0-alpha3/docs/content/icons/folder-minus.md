---
title: Folder minus
layout: icon
categories:
  - Files and folders
tags:
  - directory
  - delete
  - remove
---
