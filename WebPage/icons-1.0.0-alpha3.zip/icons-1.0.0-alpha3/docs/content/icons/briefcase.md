---
title: Briefcase
layout: icon
categories:
  - Real world
tags:
  - business
---
