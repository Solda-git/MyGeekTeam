---
title: Bounding box circles
layout: icon
categories:
  - Graphics
tags:
  - text
  - shape
  - resize
  - dimensions
---
