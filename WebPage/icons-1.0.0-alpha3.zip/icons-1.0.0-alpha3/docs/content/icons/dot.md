---
title: Dot
layout: icon
categories:
  - UI and keyboard
tags:
  - middot
---
