---
title: Layout text window
layout: icon
categories:
  - Layout
tags:
  - layout
  - columns
---
