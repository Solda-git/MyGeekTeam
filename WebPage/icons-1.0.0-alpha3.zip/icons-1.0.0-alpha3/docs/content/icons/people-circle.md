---
title: People circle
layout: icon
categories:
  - People
tags:
  - humans
  - organization
  - avatar
---
