---
title: Brightness high
layout: icon
categories:
  - UI and keyboard
tags:
  - brightness
---
