---
title: Display fill
layout: icon
categories:
  - Devices
tags:
  - monitor
  - external
---
