---
title: Filter
layout: icon
categories:
  - UI and keyboard
tags:
  - sort
---
