---
title: Plug
layout: icon
categories:
  - Real world
tags:
  - power
  - outlet
---
