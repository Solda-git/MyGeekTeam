---
title: Cone striped
layout: icon
categories:
  - Real world
tags:
  - construction
  - warning
  - safety
---
