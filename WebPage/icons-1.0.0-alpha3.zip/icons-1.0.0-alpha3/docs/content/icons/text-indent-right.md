---
title: Text indent right
layout: icon
categories:
  - Typography
tags:
  - text
  - type
  - justify
  - alignment
---
