---
title: File spreadsheet
layout: icon
categories:
  - Files and folders
tags:
  - doc
  - document
  - excel
  - table
---
