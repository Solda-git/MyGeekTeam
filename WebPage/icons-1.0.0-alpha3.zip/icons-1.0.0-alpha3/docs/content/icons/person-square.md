---
title: Person square
layout: icon
categories:
  - People
tags:
  - human
  - individual
  - avatar
---
