---
title: Tablet
layout: icon
categories:
  - Devices
tags:
  - mobile
---
