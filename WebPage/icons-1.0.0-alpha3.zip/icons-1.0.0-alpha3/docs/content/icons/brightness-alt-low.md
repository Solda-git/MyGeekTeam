---
title: Brightness alt low
layout: icon
categories:
  - UI and keyboard
tags:
  - brightness
---
