---
title: Question octagon
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - help
---
