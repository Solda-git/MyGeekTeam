---
title: Diamond half fill
layout: icon
categories:
  - Shapes
tags:
  - shape
---
