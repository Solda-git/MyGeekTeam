---
title: Battery charging
layout: icon
categories:
  - Devices
tags:
  - power
  - charge
---
