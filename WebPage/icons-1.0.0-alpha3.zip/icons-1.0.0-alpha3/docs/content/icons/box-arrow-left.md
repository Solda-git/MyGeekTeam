---
title: Box arrow left
layout: icon
categories:
  - Box arrows
tags:
  - arrow
---
