---
title: Square fill
layout: icon
categories:
  - Shapes
tags:
  - shape
  - rectangle
---
