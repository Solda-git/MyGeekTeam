---
title: Bar chart fill
layout: icon
categories:
  - Data
tags:
  - chart
  - graph
  - analytics
---
