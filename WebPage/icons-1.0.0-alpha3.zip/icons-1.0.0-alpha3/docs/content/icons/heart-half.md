---
title: Heart half
layout: icon
categories:
  - Shapes
tags:
  - love
  - favorite
---
