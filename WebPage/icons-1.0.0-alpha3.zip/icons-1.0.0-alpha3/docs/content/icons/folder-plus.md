---
title: Folder plus
layout: icon
categories:
  - Files and folders
tags:
  - directory
  - delete
  - add
  - new
---
