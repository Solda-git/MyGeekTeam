---
title: Folder symlink fill
layout: icon
categories:
  - Files and folders
tags:
  - directory
  - symbolic-link
---
