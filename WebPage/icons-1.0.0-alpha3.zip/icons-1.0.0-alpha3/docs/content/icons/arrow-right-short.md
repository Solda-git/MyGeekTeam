---
title: Arrow right-short
layout: icon
categories:
  - Arrows
tags:
  - arrow
---
