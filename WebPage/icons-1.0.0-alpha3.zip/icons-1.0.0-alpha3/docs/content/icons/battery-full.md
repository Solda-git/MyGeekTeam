---
title: Battery full
layout: icon
categories:
  - Devices
tags:
  - power
  - charge
---
