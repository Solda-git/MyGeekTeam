---
title: Question octagon fill
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - help
---
