---
title: Heart fill
layout: icon
categories:
  - Shapes
tags:
  - love
  - favorite
---
