---
title: Plus circle
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - add
  - new
---
