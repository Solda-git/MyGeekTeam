---
title: File zip
layout: icon
categories:
  - Files and folders
tags:
  - doc
  - document
  - zip
  - archive
  - compress
---
