---
title: Blockquote right
layout: icon
categories:
  - Typography
tags:
  - text
  - type
---
