---
title: Square half fill
layout: icon
categories:
  - Shapes
tags:
  - shape
  - rectangle
---
