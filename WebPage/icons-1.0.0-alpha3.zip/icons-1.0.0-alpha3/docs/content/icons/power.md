---
title: Power
layout: icon
categories:
  - UI and keyboard
tags:
  - off
  - on
---
