---
title: Clipboard
layout: icon
categories:
  - Real world
tags:
  - copy
  - paste
---
