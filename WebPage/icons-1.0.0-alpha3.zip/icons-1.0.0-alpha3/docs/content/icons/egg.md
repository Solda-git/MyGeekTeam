---
title: Egg
layout: icon
categories:
  - Real world
tags:
  - food
---
