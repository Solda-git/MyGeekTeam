---
title: File minus
layout: icon
categories:
  - Files and folders
tags:
  - doc
  - document
  - delete
  - remove
---
