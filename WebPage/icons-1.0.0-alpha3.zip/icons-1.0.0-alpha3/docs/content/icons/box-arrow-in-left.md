---
title: Box arrow in left
layout: icon
categories:
  - Box arrows
tags:
  - arrow
---
