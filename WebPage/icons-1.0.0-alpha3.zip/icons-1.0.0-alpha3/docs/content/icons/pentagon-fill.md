---
title: Pentagon fill
layout: icon
categories:
  - Shapes
tags:
  - shape
  - polygon
---
