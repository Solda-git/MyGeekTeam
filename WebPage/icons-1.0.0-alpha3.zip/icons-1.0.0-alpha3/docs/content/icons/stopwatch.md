---
title: Stopwatch
layout: icon
categories:
  - Devices
tags:
  - time
  - timer
---
