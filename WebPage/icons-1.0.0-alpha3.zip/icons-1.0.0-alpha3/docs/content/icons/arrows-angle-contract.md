---
title: Arrows angle contract
layout: icon
categories:
  - Arrows
tags:
  - arrow
---
