---
title: Cursor
layout: icon
categories:
  - Geo
tags:
  - pointer
---
