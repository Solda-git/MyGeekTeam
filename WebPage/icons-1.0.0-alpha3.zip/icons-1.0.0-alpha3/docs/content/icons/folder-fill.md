---
title: Folder fill
layout: icon
categories:
  - Files and folders
tags:
  - directory
---
