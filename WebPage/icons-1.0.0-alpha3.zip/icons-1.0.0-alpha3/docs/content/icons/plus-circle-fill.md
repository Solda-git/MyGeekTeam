---
title: Plus circle fill
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - add
  - new
---
