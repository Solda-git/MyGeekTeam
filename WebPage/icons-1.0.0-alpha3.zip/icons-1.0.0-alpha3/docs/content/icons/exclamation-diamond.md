---
title: Exclamation diamond
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
