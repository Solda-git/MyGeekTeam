---
title: File earmark minus
layout: icon
categories:
  - Files and folders
tags:
  - doc
  - document
  - delete
  - remove
---
