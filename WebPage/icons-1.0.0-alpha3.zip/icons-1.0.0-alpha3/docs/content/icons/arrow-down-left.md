---
title: Arrow down-left
layout: icon
categories:
  - Arrows
tags:
  - arrow
---
