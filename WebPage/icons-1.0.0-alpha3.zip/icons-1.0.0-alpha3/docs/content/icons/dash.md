---
title: Dash
layout: icon
categories:
  - UI and keyboard
tags:
  - minus
---
