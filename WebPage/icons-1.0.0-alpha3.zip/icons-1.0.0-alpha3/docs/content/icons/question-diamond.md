---
title: Question diamond
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - help
---
