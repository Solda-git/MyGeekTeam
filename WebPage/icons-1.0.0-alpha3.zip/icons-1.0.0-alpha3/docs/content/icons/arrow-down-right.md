---
title: Arrow down-right
layout: icon
categories:
  - Arrows
tags:
  - arrow
---
