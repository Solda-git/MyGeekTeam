---
title: Folder check
layout: icon
categories:
  - Files and folders
tags:
  - directory
  - check
  - verified
---
