---
title: Newspaper
layout: icon
categories:
  - Real world
tags:
  - news
  - paper
---
