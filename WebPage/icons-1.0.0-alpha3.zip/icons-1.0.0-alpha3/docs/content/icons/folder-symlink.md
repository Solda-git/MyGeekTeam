---
title: Folder symlink
layout: icon
categories:
  - Files and folders
tags:
  - directory
  - symbolic-link
---
