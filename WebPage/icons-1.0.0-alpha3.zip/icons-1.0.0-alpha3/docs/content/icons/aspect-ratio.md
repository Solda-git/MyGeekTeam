---
title: Aspect ratio
layout: icon
categories:
  - Media
tags:
  - size
  - resize
  - crop
  - dimensions
---
