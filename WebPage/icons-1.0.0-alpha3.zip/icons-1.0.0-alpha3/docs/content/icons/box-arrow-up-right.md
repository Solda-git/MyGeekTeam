---
title: Box arrow up-right
layout: icon
categories:
  - Box arrows
tags:
  - arrow
---
