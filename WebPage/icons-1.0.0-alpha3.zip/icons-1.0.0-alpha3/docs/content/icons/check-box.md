---
title: Check box
layout: icon
categories:
  - UI and keyboard
tags:
  - checkmark
  - todo
  - checkbox
  - select
  - done
---
