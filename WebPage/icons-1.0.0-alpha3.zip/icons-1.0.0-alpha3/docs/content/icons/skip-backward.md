---
title: Skip backward
layout: icon
categories:
  - Media
tags:
  - audio
  - video
  - av
---
