---
title: HR
layout: icon
categories:
  - Typography
tags:
  - divider
  - horizonal-rule
---
