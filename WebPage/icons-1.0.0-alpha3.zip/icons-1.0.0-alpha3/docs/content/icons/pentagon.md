---
title: Pentagon
layout: icon
categories:
  - Shapes
tags:
  - shape
  - polygon
---
