---
title: Star fill
layout: icon
categories:
  - Shapes
tags:
  - shape
  - like
  - favorite
---
