---
title: File earmark ruled
layout: icon
categories:
  - Files and folders
tags:
  - doc
  - document
---
