---
title: File earmark spreadsheet
layout: icon
categories:
  - Files and folders
tags:
  - doc
  - document
  - excel
  - table
---
