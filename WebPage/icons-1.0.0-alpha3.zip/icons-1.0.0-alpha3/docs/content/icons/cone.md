---
title: Cone
layout: icon
categories:
  - Real world
tags:
  - construction
  - warning
  - safety
---
