---
title: Caret right fill
layout: icon
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
