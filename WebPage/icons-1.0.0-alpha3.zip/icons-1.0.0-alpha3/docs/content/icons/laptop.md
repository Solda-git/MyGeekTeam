---
title: Laptop
layout: icon
categories:
  - Devices
tags:
  - computer
---
