---
title: Arrow left-short
layout: icon
categories:
  - Arrows
tags:
  - arrow
---
