---
title: Fullscreen exit
layout: icon
categories:
  - UI and keyboard
tags:
  - window
  - minimize
---
