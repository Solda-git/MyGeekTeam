---
title: Square
layout: icon
categories:
  - Shapes
tags:
  - shape
  - rectangle
---
