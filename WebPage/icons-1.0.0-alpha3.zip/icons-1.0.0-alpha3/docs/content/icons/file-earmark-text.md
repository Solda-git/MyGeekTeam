---
title: File earmark text
layout: icon
categories:
  - Files and folders
tags:
  - doc
  - document
---
