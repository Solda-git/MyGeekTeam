---
title: Bar chart
layout: icon
categories:
  - Data
tags:
  - chart
  - graph
  - analytics
---
