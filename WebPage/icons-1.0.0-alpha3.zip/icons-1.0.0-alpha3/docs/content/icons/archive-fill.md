---
title: Archive fill
layout: icon
categories:
  - Files and folders
tags:
  - box
  - delete
---
