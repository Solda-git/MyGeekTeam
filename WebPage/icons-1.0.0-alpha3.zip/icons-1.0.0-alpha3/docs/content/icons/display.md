---
title: Display
layout: icon
categories:
  - Devices
tags:
  - monitor
  - external
---
