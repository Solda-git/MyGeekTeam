---
title: Speaker
layout: icon
categories:
  - Devices
tags:
  - audio
  - sound
---
