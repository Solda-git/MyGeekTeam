---
title: App indicator
layout: icon
categories:
  - Apps
tags:
  - app
  - application
  - ios
  - android
  - notification
---
