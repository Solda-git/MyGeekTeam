---
title: Circle slash
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - shape
  - stop
  - ban
  - no
---
