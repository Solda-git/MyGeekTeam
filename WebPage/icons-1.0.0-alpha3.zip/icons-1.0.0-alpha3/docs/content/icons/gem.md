---
title: Gem
layout: icon
categories:
  - Shapes
tags:
  - shape
  - diamond
---
