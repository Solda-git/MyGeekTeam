---
title: Dash square
layout: icon
categories:
  - UI and keyboard
tags:
  - minus
---
