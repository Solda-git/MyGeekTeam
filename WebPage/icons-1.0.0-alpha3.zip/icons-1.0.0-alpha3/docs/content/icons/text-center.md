---
title: Text center
layout: icon
categories:
  - Typography
tags:
  - text
  - type
  - justify
  - alignment
---
