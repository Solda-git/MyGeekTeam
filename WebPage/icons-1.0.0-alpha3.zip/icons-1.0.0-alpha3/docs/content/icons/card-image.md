---
title: Card image
layout: icon
categories:
  - Files and folders
tags:
  - note
  - card
  - notecard
---
