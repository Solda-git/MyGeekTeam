---
title: Bounding box
layout: icon
categories:
  - Graphics
tags:
  - text
  - shape
  - resize
  - dimensions
---
