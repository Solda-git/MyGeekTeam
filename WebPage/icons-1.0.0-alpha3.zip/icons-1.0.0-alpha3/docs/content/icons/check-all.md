---
title: Check all
layout: icon
categories:
  - UI and keyboard
tags:
  - checkmark
  - todo
  - done
  - select
---
