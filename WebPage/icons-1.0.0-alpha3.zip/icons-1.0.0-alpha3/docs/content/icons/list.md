---
title: List
layout: icon
categories:
  - Typography
tags:
  - text
  - type
  - justify
  - alignment
---
