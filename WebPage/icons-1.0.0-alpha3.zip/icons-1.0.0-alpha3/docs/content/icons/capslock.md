---
title: Capslock
layout: icon
categories:
  - UI and keyboard
tags:
  - key
---
