---
title: Caret right
layout: icon
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
