---
title: Pentagon half
layout: icon
categories:
  - Shapes
tags:
  - shape
  - polygon
---
