---
title: Option
layout: icon
categories:
  - UI and keyboard
tags:
  - key
  - mac
---
