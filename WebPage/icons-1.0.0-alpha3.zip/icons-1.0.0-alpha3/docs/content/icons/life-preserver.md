---
title: Life preserver
layout: icon
categories:
  - Real world
tags:
  - lifesaver
  - water
---
