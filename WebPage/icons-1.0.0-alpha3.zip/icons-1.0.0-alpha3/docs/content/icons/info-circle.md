---
title: Info circle
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - information
  - help
---
