---
title: Funnel fill
layout: icon
categories:
  - Real world
tags:
  - sort
  - filter
---
