---
title: Layout text sidebar
layout: icon
categories:
  - Layout
tags:
  - layout
  - columns
---
