---
title: Envelope open
layout: icon
categories:
  - Communications
tags:
  - email
  - message
  - mail
---
