---
title: Image
layout: icon
categories:
  - Files and folders
tags:
  - picture
  - photo
---
