---
title: Box arrow in up right
layout: icon
categories:
  - Box arrows
tags:
  - arrow
---
