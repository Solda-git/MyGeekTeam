---
title: Subtract
layout: icon
categories:
  - Graphics
tags:
  - graphics
  - vector
  - merge
  - layers
---
