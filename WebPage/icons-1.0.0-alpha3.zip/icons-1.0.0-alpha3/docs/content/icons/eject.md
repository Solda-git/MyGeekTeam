---
title: Eject
layout: icon
categories:
  - UI and keyboard
tags:
  - disc
  - cd
  - dvd
---
