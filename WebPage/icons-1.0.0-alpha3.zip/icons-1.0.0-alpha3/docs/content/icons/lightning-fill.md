---
title: Lightning fill
layout: icon
categories:
  - Misc
tags:
  - weather
  - storm
  - thunder
  - bolt
---
