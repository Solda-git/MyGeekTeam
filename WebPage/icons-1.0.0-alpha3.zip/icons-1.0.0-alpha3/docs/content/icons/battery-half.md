---
title: Battery half
layout: icon
categories:
  - Devices
tags:
  - power
  - charge
---
