---
title: Brightness alt high fill
layout: icon
categories:
  - UI and keyboard
tags:
  - brightness
---
