---
title: Blockquote left
layout: icon
categories:
  - Typography
tags:
  - text
  - type
---
