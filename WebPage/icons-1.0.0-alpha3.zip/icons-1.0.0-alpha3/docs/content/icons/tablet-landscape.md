---
title: Tablet landscape
layout: icon
categories:
  - Devices
tags:
  - mobile
---
