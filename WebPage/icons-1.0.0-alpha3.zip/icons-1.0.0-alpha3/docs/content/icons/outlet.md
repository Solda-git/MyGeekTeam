---
title: Outlet
layout: icon
categories:
  - Real world
tags:
  - plug
  - power
---
