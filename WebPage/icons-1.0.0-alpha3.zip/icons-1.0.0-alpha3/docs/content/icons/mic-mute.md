---
title: Mic mute
layout: icon
categories:
  - Media
tags:
  - audio
  - video
  - av
  - sound
  - input
  - microphone
---
