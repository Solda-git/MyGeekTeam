---
title: Egg fried
layout: icon
categories:
  - Real world
tags:
  - food
---
