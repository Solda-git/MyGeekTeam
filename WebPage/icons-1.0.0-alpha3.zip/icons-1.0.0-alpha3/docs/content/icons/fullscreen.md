---
title: Fullscreen
layout: icon
categories:
  - UI and keyboard
tags:
  - window
  - maximize
---
